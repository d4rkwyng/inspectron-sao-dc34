J3 TFT PANEL HAND-SOLDER INSTRUCTIONS (Newvisio N114-2413THBIG01-H13, LCSC C2890618)

1. Panel mounts on the BOARD FRONT, landscape, display facing UP,
   inside the white silkscreen rectangle (the "TV screen" area).
2. The FPC tail exits the panel's RIGHT edge and folds 180 degrees
   UNDER the panel (see the fold diagram on datasheet page 5).
3. After the fold, the 13 tail contacts face DOWN onto the J3 pad
   column (13 pads, 0.7mm pitch, at the right side of the screen area).
4. PIN 1 = the TOP pad of the column. It is marked "1" on the
   silkscreen. Pin 13 = bottom pad, marked "13".
   Cross-check: panel pin 3 (SDA) is the 3rd pad from the TOP.
5. Solder the 13 joints, then adhesive-mount the panel body
   (double-sided tape) inside the silk rectangle.
6. See finished-board-front-reference.png for the final appearance
   (the test-card image shows the intended panel position).

IF ANYTHING ABOUT THE FOLD DIRECTION OR PIN-1 ORIENTATION LOOKS
AMBIGUOUS, STOP AND CONTACT THE CUSTOMER BEFORE SOLDERING ANY PANELS.
